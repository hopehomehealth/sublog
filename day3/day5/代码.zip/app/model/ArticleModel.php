<?php
/**
 * ArticleModel.php
 * Created by day11.
 * User: 苏小林
 * Date: 2016/6/1
 * Time: 14:57
 */

namespace app\model;


class ArticleModel extends \core\Model
{
    protected $table = 'article';
}